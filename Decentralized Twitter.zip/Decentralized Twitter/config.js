
//export const DecentratwitterAddress = "0x610178dA211FEF7D417bC0e6FeD39F05609AD788"
export const DecentratwitterAddress = "0x5a20e760b1e4BC6E96e43b8e2345DD0753b9d859"
